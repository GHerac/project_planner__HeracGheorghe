import { createSlice } from "@reduxjs/toolkit";


const taskObj = {
  taskName: "",
  descValue: "",
  taskPriority: "",
  createdDate: new Date(),
  projectName: "",
  assignedPersons: [],
  timeline: { startDate: new Date(), endDate: new Date() },
};

export const taskSlice = createSlice({
  name: "task",
  initialState: {
    value: [],
  },
  reducers: {
    createTaskRedux: (state, action) => {

      state.value.push(action.payload);
    },
    
    removeTaskRedux: (state, action) => {

      state.value = state.value.filter((task, id) => id !== action.payload);
    },



    updateTaskRedux: (state, action) => {
      const { index, taskToBeUpdate } = action.payload;
    
      // Check if the index is valid
      if (index >= 0 && index < state.value.length) {
        // Update the task at the specified index
        state.value[index] = { ...state.value[index], ...taskToBeUpdate };

          // const taskIndex = state.value.findIndex(itemArray => itemArray.id === index );
          // if (taskIndex !== -1){
          //   state.value[taskIndex].taskName = taskToBeUpdate.taskName;
          //   state.value[taskIndex].descValue = taskToBeUpdate.descValue;
          //   state.value[taskIndex].taskPriority = taskToBeUpdate.taskPriority;
        
          // }
      } else {
        console.error("Invalid index provided for task update:", index);
      }
    },
    

    clearTasks: (state) => {
      state.value = [];
    }
    
    
  },
});

export const { createTaskRedux, removeTaskRedux, updateTaskRedux, clearTasks } =
  taskSlice.actions;

export default taskSlice.reducer;
