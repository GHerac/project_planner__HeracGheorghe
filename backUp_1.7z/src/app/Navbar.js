// renders the top header and nav content
