import "./ToDoList.css";
import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { createTaskRedux, removeTaskRedux, updateTaskRedux } from "../../features/taskSlice";

import NewToDoForm from "../NewToDoForm/NewToDoForm";
import TodoListItem from "../ToDoListItem/TodoListItem";




const TodoList = () => {
  const tasksRedux = useSelector((state) => state.task.value);
  const dispatch = useDispatch();
  const [tasks, setTasks] = useState([tasksRedux]);
  // Fetch tasks from Redux store on component mount
  useEffect(() => {
    setTasks(tasksRedux);
  }, [tasksRedux]);


  const createTask = (taskObj) => {
   
    dispatch(createTaskRedux(taskObj));
  };

  const handleRemoveTask = (indexToRemove) => {
    dispatch(removeTaskRedux(indexToRemove));
  };

  // const handleUpdateTask = (indexToBeUpdated, updatedTask) => {
  //   console.log("handleUpdateTask ->updatedTask", updatedTask);
  //   // dispatch(updateTaskRedux({ index: indexToBeUpdated, taskUpdate: updatedTask }));
  // };

  return (
    <div >
      <NewToDoForm createTask={createTask} />
      {tasks.map((taskItem, index) => (
        <TodoListItem
          key={index} // Ensure each item has a unique key
          index={index}
          todoObj={taskItem}
          removeTask={() => handleRemoveTask(index)}
          // updateTask={() => handleUpdateTask(index, taskItem)}
        />
      ))}
    </div>
  );
};

export default TodoList;

