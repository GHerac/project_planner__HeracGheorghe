import TodoList from '../ToDoList/ToDoList';

import React from 'react';


const Homepage = () => {

    
    return(
    <>
    
         <TodoList />
    
    </>
    
        
      
    )
}

export default Homepage;