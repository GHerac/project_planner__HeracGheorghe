import TaskListTable from    '../TaskListTable/TaskListTable';

const TaskList = () => {

    return(
        <>
                <h1> see the table with all ToDo list </h1>
                <TaskListTable />        
        </>
    )
}

export default TaskList;