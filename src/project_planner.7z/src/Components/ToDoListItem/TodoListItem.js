import React from "react";
import './TodoListItem.css';
import 'bootstrap/dist/css/bootstrap.css';

const TodoListItem = ( {todo}) => (

    <div className="todo-item-container">

        <h3> {todo}</h3>
        
        <div className="to-do-buttons-container">
            <button className="completed-button btn btn-outline-primary"> Mark As completed</button>
            <button className="remove-button btn btn-outline-primary" >Remove Task</button>
        </div>
    </div>
);

export default TodoListItem;