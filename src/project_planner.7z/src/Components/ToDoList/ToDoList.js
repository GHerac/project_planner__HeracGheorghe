import React from 'react';
import { useState } from 'react';
import NewToDoForm from '../NewToDoForm/NewToDoForm';
import TodoListItem from '../ToDoListItem/TodoListItem';
import './ToDoList.css';




const TodoList = () => {
    const [tasks, setTasks] = useState([]);

    const createTask = taskName => {
        setTasks([...tasks, taskName]);
    };

    return (
        <div className='list-wrapper'>
            <NewToDoForm createTask={createTask} />
            {tasks.map((task, index) => (
                <TodoListItem key={index} task={task} />
            ))}
        </div>
    );
};


export default TodoList;
