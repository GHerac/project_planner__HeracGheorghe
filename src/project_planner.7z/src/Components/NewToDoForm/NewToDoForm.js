import React from "react";
import { useState } from 'react';

import './NewToDoForm.css';



const NewToDoForm = ( {createTask} ) => {
    const [inputValue, setInputValue] = useState('');

    const onTitleChanged = e => setInputValue(e.target.value);

    const handleCreateTask = () => {
        if (inputValue.trim() !== '') {
            createTask(inputValue); // Call createTask function with inputValue
            // console.log(inputValue);
            // tasks.push(inputValue);
            setInputValue(''); // Reset inputValue after creating task
        }
    };

    return (
        <div className="new-todo-form">
            <input
                type='text'
                className="new-todo-input"
                placeholder="Type your new TODO here"
                value={inputValue}
                onChange={onTitleChanged}
            />
            <button
                className="newToDoForm"
                onClick={handleCreateTask} // Call handleCreateTask function when button is clicked
            >
                Create ToDo
            </button>
        </div>
    );
};

export default NewToDoForm;




