export const CREATE_TODO='CREATE_TODO';

                // action created for createToDo
export const createToDo= text => ({
    type:CREATE_TODO,
    payload: {text},
});

                // createToDo('Go to the store ');

export const REMOVE_TODO='REMOVE_TODO';

// action created for removeToDo
export const removeToDo = text => ({
    type: REMOVE_TODO,
    payload: {text},
});


/*
A typical action object might look like this
        const addTodoAction = {
            type: 'todos/todoAdded',
            payload: 'Buy milk'
        }

    An action creator is a function that creates and returns an action object

    const addTodo = text => {
     return {
                type: 'todos/todoAdded',
                payload: text
        }
}

*/