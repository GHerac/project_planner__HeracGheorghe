import { CREATE_TODO, REMOVE_TODO } from "./actions";

// An action creator is a function that creates and returns an action object
export const todos = (state = [], action) => {
    const { type, payload } = action;

    switch(type) {
        case CREATE_TODO: {
            const { text } = payload;
            
            const newToDo = {
                    text,
                    isCompleted: false,
                };

            return state.concat(newToDo); //  concat returns a shallow copy  - https://developer.mozilla.org/en-US/docs/Glossary/Shallow_copy
        };

        case REMOVE_TODO:{
            const {text} = payload;
            return state.filter(todo => todo.txt !== text);

        };
        default:
            return state;
    }
}


/*
A typical action object might look like this
        const addTodoAction = {
            type: 'todos/todoAdded',
            payload: 'Buy milk'
        }

    An action creator is a function that creates and returns an action object

    const addTodo = text => {
     return {
                type: 'todos/todoAdded',
                payload: text
        }
}

*/


const initialState = { value: 0 }

function todoReducer(state = initialState, action) {
  // Check to see if the reducer cares about this action
  if (action.type === CREATE_TODO) {
    // If so, make a copy of `state`
    return {
      ...state,
      // and update the copy with the new value
      value: state.value + 1
    }
  }
  // otherwise return the existing state unchanged
  return state
}

